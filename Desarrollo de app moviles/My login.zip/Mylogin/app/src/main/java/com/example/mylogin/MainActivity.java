package com.example.mylogin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.BuildCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;




public class MainActivity extends AppCompatActivity {
    private Button b1, b2;
    private EditText ed1, ed2;




    int contador=3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        b1=(Button) findViewById(R.id.entrada);
        b2=(Button) findViewById(R.id.salida);
        ed1=(EditText) findViewById(R.id.Email);
        ed2=(EditText) findViewById(R.id.Contraseña);

        b1.setOnClickListener(new View.OnClickListener(){
                                  public void onClick(View v) {
                                      if (ed1.getText().toString().equals("admin")&& ed2.getText().toString().equals("1234")) {
                                          Intent intent = new Intent(MainActivity.this, Entrada.class);
                                          startActivity(intent);
                                      }else {
                                          Toast.makeText(getApplicationContext(), "Incorrecto", Toast.LENGTH_SHORT).show();
                                          contador--;

                                      }
                                  }
                              });
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();

            }
        });

    }
}